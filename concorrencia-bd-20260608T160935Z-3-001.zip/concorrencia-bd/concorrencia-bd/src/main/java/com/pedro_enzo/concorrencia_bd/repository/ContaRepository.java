package com.pedro_enzo.concorrencia_bd.repository;

import com.pedro_enzo.concorrencia_bd.entity.ContaBancaria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ContaRepository extends JpaRepository<ContaBancaria, Long> {
}