package com.pedro_enzo.concorrencia_bd.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class ContaBancariaVersionada {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private BigDecimal saldo;

    @Version
    private Integer version;

    public ContaBancariaVersionada() {}

    public ContaBancariaVersionada(BigDecimal saldo) {
        this.saldo = saldo;
    }

    public Long getId() { return id; }
    public BigDecimal getSaldo() { return saldo; }
    public void setSaldo(BigDecimal saldo) { this.saldo = saldo; }
    public Integer getVersion() { return version; }
}