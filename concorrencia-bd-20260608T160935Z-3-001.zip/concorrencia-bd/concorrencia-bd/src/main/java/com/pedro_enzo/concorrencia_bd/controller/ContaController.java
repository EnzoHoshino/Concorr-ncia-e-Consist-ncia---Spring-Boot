package com.pedro_enzo.concorrencia_bd.controller;

import com.pedro_enzo.concorrencia_bd.service.ContaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;

@RestController
@RequestMapping("/contas")
public class ContaController {

    private final ContaService service;

    public ContaController(ContaService service) {
        this.service = service;
    }

    @PostMapping("/{id}/deposito")
    public String deposito(@PathVariable Long id, @RequestParam BigDecimal valor) {
        service.deposito(id, valor);
        return "Depósito realizado";
    }

    @PostMapping("/{id}/saque")
    public String saque(@PathVariable Long id, @RequestParam BigDecimal valor) {
        service.saque(id, valor);
        return "Saque realizado";
    }

    @PostMapping("/versionadas/{id}/deposito")
    public String depositoVersionado(@PathVariable Long id, @RequestParam BigDecimal valor) {
        service.depositoVersionado(id, valor);
        return "Depósito versionado realizado";
    }

    @PostMapping("/versionadas/{id}/saque")
    public String saqueVersionado(@PathVariable Long id, @RequestParam BigDecimal valor) {
        service.saqueVersionado(id, valor);
        return "Saque versionado realizado";
    }

    @ExceptionHandler(ObjectOptimisticLockingFailureException.class)
    public ResponseEntity<String> handleConcurrencyFailure() {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body("Erro de concorrência: A conta foi atualizada por outro usuário.");
    }
}