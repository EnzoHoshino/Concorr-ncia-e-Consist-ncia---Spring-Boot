package com.pedro_enzo.concorrencia_bd.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class ContaBancaria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private BigDecimal saldo;

    public ContaBancaria() {}

    public ContaBancaria(BigDecimal saldo) {
        this.saldo = saldo;
    }

    public Long getId() { return id; }
    public BigDecimal getSaldo() { return saldo; }
    public void setSaldo(BigDecimal saldo) { this.saldo = saldo; }
}