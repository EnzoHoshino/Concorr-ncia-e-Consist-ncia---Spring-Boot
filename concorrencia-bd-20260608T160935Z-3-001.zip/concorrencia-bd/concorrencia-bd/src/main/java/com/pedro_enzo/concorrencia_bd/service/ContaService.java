package com.pedro_enzo.concorrencia_bd.service;

import com.pedro_enzo.concorrencia_bd.entity.ContaBancaria;
import com.pedro_enzo.concorrencia_bd.entity.ContaBancariaVersionada;
import com.pedro_enzo.concorrencia_bd.repository.ContaRepository;
import com.pedro_enzo.concorrencia_bd.repository.ContaVersionadaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;

@Service
public class ContaService {

    private final ContaRepository repository;
    private final ContaVersionadaRepository versionadaRepository;

    public ContaService(ContaRepository repository, ContaVersionadaRepository versionadaRepository) {
        this.repository = repository;
        this.versionadaRepository = versionadaRepository;
    }

    @Transactional
    public void deposito(Long id, BigDecimal valor) {
        ContaBancaria conta = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Conta não encontrada"));
        conta.setSaldo(conta.getSaldo().add(valor));
        repository.save(conta);
    }

    @Transactional
    public void saque(Long id, BigDecimal valor) {
        ContaBancaria conta = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Conta não encontrada"));
        if (conta.getSaldo().compareTo(valor) < 0) {
            throw new RuntimeException("Saldo insuficiente");
        }
        conta.setSaldo(conta.getSaldo().subtract(valor));
        repository.save(conta);
    }

    @Transactional
    public void depositoVersionado(Long id, BigDecimal valor) {
        ContaBancariaVersionada conta = versionadaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Conta versionada não encontrada"));
        conta.setSaldo(conta.getSaldo().add(valor));
        versionadaRepository.save(conta);
    }

    @Transactional
    public void saqueVersionado(Long id, BigDecimal valor) {
        ContaBancariaVersionada conta = versionadaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Conta versionada não encontrada"));
        if (conta.getSaldo().compareTo(valor) < 0) {
            throw new RuntimeException("Saldo insuficiente");
        }
        conta.setSaldo(conta.getSaldo().subtract(valor));
        versionadaRepository.save(conta);
    }
}