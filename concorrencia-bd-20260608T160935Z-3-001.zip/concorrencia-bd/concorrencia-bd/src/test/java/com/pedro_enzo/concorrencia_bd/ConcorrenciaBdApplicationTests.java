package com.pedro_enzo.concorrencia_bd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConcorrenciaBdApplicationTests {

	@Test
	void contextLoads() {
	}

}
